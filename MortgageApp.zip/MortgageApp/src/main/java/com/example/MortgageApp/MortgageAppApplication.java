package com.example.MortgageApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MortgageAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MortgageAppApplication.class, args);
	}

}
